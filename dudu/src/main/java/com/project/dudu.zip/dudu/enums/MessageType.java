package com.project.dudu.enums;

public enum MessageType {
    Success,
    Notice,
    Finish,
    Warning
}
